import { createSlice } from "@reduxjs/toolkit";

const CartSlice = createSlice({
    name  : "cart",
    initialState  : {
        cart : []
    },
    reducers:{
        addToCart : (state, action)=>{
                      state.cart = [...state.cart , action.payload]
                    },
        removeFromCart : (state,action)=>{
            state.cart = state.cart.filter(i=>i.id!==action.payload)
        }
    }
})
export const {addToCart,removeFromCart} = CartSlice.actions
export default CartSlice.reducer