import { createSlice } from "@reduxjs/toolkit";

const ProductSlice = createSlice({
    name : "products",
    initialState : {
        product : []
    },
    reducers:{
        addProduct : (state, action)=>{
            state.product = action.payload
        }
    }
})
export const {addProduct}= ProductSlice.actions
export default ProductSlice.reducer