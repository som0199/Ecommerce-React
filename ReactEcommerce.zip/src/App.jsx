import React from 'react'
import Navbar from './components/Navbar'
import Home from './pages/Home'
import { BrowserRouter as Router ,Routes, Route, BrowserRouter } from 'react-router-dom'
import About from './pages/About'
import Contact from './pages/Contact'
import Women from './pages/Women'
import Men from './pages/Men'
import Cart from './pages/Cart'
import Electronics from './pages/Electronics'


const App = () => {
  return (
    <Router>
      <Navbar/>
      <Routes>
        <Route path='/' element={<Home/>}></Route>
        <Route path='/men' element={<Men/>}></Route>
        <Route path='/women' element={<Women/>}></Route>
        <Route path='/electronics' element={<Electronics/>}></Route>
        <Route path='/about' element={<About/>}></Route>
        <Route path='/contact' element={<Contact/>}></Route>
        <Route path='/cart' element={<Cart/>}></Route>
      </Routes>
    </Router>
  )
}

export default App