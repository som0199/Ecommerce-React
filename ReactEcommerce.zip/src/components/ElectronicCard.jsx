import React from 'react'

const ElectronicCard = ({i}) => {
  return (
    <div className="col ">
    <div className="card text-start mb-3 d-flex align-items-center justify-content-center">
        <img src={i.image} alt="" className='card-img-top' />
      <div className="card-body ">
        <h5 className="card-title text-secondary">{i.title}</h5>
        <p className="card-text fs-5  fw-bold">${i.price}</p>
        <div className='text-center'>
        <a href="#" className="btn btn-warning w-100">Add to Cart</a>
        </div>
        </div>
    </div>
  </div>
  )
}

export default ElectronicCard