import React from 'react'
import { useDispatch } from 'react-redux'
import { removeFromCart } from '../Store/CartSlice'

const CartContainer = ({i}) => {
   const dispatch = useDispatch()

    const removeProduct =()=>{
        dispatch(removeFromCart(i.id))
    }

  return (
    <div className="col ">
    <div className="card text-start mb-3 d-flex align-items-center justify-content-center">
        <img src={i.image} alt="" className='card-img-top' />
      <div className="card-body ">
        <h5 className="card-title text-secondary">{i.title}</h5>
        <p className="card-text fs-5  fw-bold">${i.price}</p>
        <div className='text-center'>
        <a href="#" className="btn btn-danger btn-info w-100" onClick={()=>removeProduct()}>Remove</a>
        </div>
        </div>
    </div>
  </div>
  )
}

export default CartContainer