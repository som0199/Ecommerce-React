import React from 'react'

const ElectronicCarousel = () => {
  return (
    <div id="carouselExampleInterval" className="carousel slide" data-bs-ride="carousel">
  <div className="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" className="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div className="carousel-inner">
    <div className="carousel-item active">
      <img src="https://assets.ajio.com/cms/AJIO/WEB/D-1.0-WHP-220224-MAINBANNER-Z1-P7-INDIEPICKS-NYRIKA-MIN70.jpg" className="d-block w-100" alt="..."/>
    </div>
    <div className="carousel-item">
      <img src="https://assets.ajio.com/cms/AJIO/WEB/D-1.0-WHP-220224-MAINBANNER-Z1-P5-STYLI-USPA-MIN50.jpg" className="d-block w-100" alt="..."/>
    </div>
    <div className="carousel-item">
      <img src="https://assets.ajio.com/cms/AJIO/WEB/D-1.0-WHP-220224-MAINBANNER-Z1-P3-AVAASA-FUSION-MIN60.jpg" className="d-block w-100" alt="..."/>
    </div>
  </div>
</div>
  )
}

export default ElectronicCarousel