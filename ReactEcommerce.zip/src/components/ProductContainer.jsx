import React, { useEffect} from 'react'
import { useDispatch, useSelector } from 'react-redux';
import Products from './Products';
import { addProduct } from '../Store/ProductSlice';

const ProductContainer = () => {

    const dispatch =  useDispatch()
    const {product} = useSelector(state=>state.product)
    
    const fetchProducts = async() =>{
        const response =  await fetch(`https://fakestoreapi.com/products`)
        const data = await response.json();
        dispatch(addProduct(data))
    }

    

    useEffect(()=>{
        fetchProducts()
    },[])

  return (
    <div className='home'>
 <h1 className='text-center pt-3'>All Products</h1>
 <div className="row row-cols-1 row-cols-lg-5 row-cols-md-3 g-4 p-5 ">
    
  {
    product.map((items,index)=>
    <Products key={index} item={items}/>
    )
  }
 </div>

    </div>
  )
}

export default ProductContainer