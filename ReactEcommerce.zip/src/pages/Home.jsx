import React from 'react'
import ImageCarousel from '../components/ImageCarousel'
import ProductContainer from '../components/ProductContainer'

const Home = () => {
  return (
    <>
    <ImageCarousel/>
    <ProductContainer/>
    </>
  )
}

export default Home