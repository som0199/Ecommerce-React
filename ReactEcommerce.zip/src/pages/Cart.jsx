import React from 'react'
import CartContainer from '../components/CartContainer'
import { useSelector } from 'react-redux'

const Cart = () => {
    const {cart} = useSelector(state=>state.cart)
  return (
    <>
       <div className="row row-cols-1 row-cols-md-6 g-4 px-5 ">
          {
            cart?.map((i,index)=> 
                <CartContainer key={index} i={i}/>
                )
          }
       </div>
       
    </>
  )
}

export default Cart